d=["Ash","Gray","Silver","White"]
print(d)
print(len(d))
print(d.count("Silver"))
print(d.index("Ash"))

set = {"BCA","MCA","BBA", "MBA","MSC"}
print(set)
print(type(set))

# print(set[0])