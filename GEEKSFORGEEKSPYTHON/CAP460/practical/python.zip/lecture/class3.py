l1 = [1, 7, 99, 3, 2, 7]
l2 = ["koushik", "mondal", "arijit", "suman"]

l1.sort()
print(l1)
l1.sort(reverse=True)
print(l1)
l2.sort()
print(l2)