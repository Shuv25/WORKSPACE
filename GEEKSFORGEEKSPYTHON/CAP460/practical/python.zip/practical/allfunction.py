# All function
list = [4,5,6,8,True, "Gagandeep", 0.01]
print(all(list))

# Any function
list = [8,9,3,"Gagan", 0.025, False]
print(any(list))

an1 = []
print(any(an1))