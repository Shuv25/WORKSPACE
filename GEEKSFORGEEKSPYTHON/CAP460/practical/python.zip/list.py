"""nums=[5,4,3,2,1]
print(nums[-6])"""

"""hall=11.23
kitchen=28.0
living=20.0
bedroom=20.75
bathroom=9.50

area_of_all_rooms=[11.23,28.0,20.0,20.75,9.50]

print(area_of_all_rooms)

print("area of hall is ", area_of_all_rooms[0])"""

"""l=["ram","raj","rahul"]
print(max[1])"""


