list=["koushik","rahul",45,78]

len(list)