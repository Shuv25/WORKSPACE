num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
sum = num1+num2
print("Sum of",num1,"and",num2, "is", sum)

