num1=int(input("Enter first number :"))
num2=int(input("Enter first number :"))
num3=int(input("Enter first number :"))
num4=int(input("Enter first number :"))

if(num1>num2):
    f1=num1
else:
    f1=num2

if(num3>num4):
    f2=num3
else:
    f2=num4

if(f1>f2):
    print(f1, " is the greatest number")
else:
    print(f2, " is the greatest number")

    
                    
        
    

    