name = input("Enter your name")
if(len(name)<10):
    print("Your username is Correct ")
else:
    print("Your username is too long")