names=["koushik", "rahul", "suman", "arijit"]
name= input("Enter your name")

if name in names:
    print("your name is in the list")
else:
    print("your name is not in list")
