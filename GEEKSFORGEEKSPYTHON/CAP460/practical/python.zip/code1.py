startp=2
while(startp<=10):
    print(startp)
    startp=startp+1