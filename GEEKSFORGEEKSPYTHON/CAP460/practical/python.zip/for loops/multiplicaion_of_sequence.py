# enter the length of sequence
n = int(input("Enter the length of Series: "))

sequence=1

while(n):
    print(sequence, end =" ")
    sequence*=2
    n-=1