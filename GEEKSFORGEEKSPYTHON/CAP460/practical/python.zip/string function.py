str = " Hello to everyone! I am koushik M " 
print(str) 
print(str.upper()) 
print(str.lower()) 
 
# To remove whitespaces 
print(str.strip()) 
 
# To replace string in another one char 
print(str.replace('o', 'k')) 
 
# To replace string in another one string 
print(str.replace("Koushik", "Ashish"))

