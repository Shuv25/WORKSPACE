num=int(input("Enter your age :"))
if(num>=18):
    print("You are elegible to vote")
else:
    print("you are not elegible to vote")