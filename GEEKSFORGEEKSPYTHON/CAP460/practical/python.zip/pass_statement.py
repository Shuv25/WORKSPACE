i=9
if i<50:
    pass
else:
    pass
print("hello world")