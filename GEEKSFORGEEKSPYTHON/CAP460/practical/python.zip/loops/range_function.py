for i in range(1,9,2): #start , stop , stap size
    print(i)