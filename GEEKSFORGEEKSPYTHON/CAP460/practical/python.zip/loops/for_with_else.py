for i in range(10): #start , stop , stap size
    print(i)
else:
    print("this is inside of a for loop")