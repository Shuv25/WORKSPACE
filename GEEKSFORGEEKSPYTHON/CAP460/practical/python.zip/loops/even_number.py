# Python program to print all even numbers in range
for even_numbers in range(4,15,2):
#here inside range function first no denotes starting,
#second denotes end and
#third denotes the interval
	print(even_numbers)
