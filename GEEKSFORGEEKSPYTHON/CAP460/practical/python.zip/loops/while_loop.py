i=0
while i<10:
    print("hello world" , str(i))
    i+=1