fruits=["mango", "banana", "orange"]

for item in fruits:
    print(item)