 
number = int(input("Please Enter any Number: "))

print("The List of Natural Numbers are") 

for i in range(1, number + 1):
    print (i)