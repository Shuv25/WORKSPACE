a=input("Please enter your name")
print(str(a))
